/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.3691623424759, "KoPercent": 1.630837657524092};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.38510007412898445, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.73, 500, 1500, "Cart-0"], "isController": false}, {"data": [0.0, 500, 1500, "Products"], "isController": false}, {"data": [0.0, 500, 1500, "Cart-2"], "isController": false}, {"data": [0.87, 500, 1500, "HomePage-0"], "isController": false}, {"data": [0.7, 500, 1500, "Cart-1"], "isController": false}, {"data": [0.0, 500, 1500, "HomePage-1"], "isController": false}, {"data": [0.9, 500, 1500, "Mens-Clothing-1"], "isController": false}, {"data": [0.0, 500, 1500, "Mens-Clothing-2"], "isController": false}, {"data": [0.81, 500, 1500, "Womens-traditional-clothing-0"], "isController": false}, {"data": [0.89, 500, 1500, "Womens-traditional-clothing-1"], "isController": false}, {"data": [0.01, 500, 1500, "Womens-traditional-clothing-2"], "isController": false}, {"data": [0.83, 500, 1500, "Mens-Clothing-0"], "isController": false}, {"data": [0.0, 500, 1500, "Cart"], "isController": false}, {"data": [0.7, 500, 1500, "Products-1"], "isController": false}, {"data": [0.0, 500, 1500, "Products-2"], "isController": false}, {"data": [0.66, 500, 1500, "Products-0"], "isController": false}, {"data": [0.01, 500, 1500, "Womens-traditional-clothing"], "isController": false}, {"data": [0.0, 500, 1500, "Skincare Beauty"], "isController": false}, {"data": [0.0, 500, 1500, "Mens-Clothing"], "isController": false}, {"data": [0.86, 500, 1500, "Skincare Beauty-0"], "isController": false}, {"data": [0.82, 500, 1500, "Skincare Beauty-1"], "isController": false}, {"data": [0.01, 500, 1500, "mens-shoes-2"], "isController": false}, {"data": [0.0, 500, 1500, "HomePage"], "isController": false}, {"data": [0.0, 500, 1500, "Skincare Beauty-2"], "isController": false}, {"data": [0.84, 500, 1500, "mens-shoes-1"], "isController": false}, {"data": [0.74, 500, 1500, "mens-shoes-0"], "isController": false}, {"data": [0.01, 500, 1500, "mens-shoes"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1349, 22, 1.630837657524092, 27220.727946627117, 0, 288739, 5804.0, 82465.0, 99191.5, 164920.0, 3.18891420898853, 1066.9109031715984, 0.5861988228320584], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Cart-0", 50, 0, 0.0, 721.7199999999999, 392, 2061, 439.0, 1420.0, 1832.2999999999997, 2061.0, 0.22079831840000708, 0.17659553004844317, 0.025443556221875815], "isController": false}, {"data": ["Products", 50, 0, 0.0, 33695.32, 13672, 90595, 28498.5, 58975.799999999996, 72456.35, 90595.0, 0.19580890617228833, 78.95165777938993, 0.07170736310020324], "isController": false}, {"data": ["Cart-2", 50, 2, 4.0, 91794.45999999998, 60035, 262704, 81641.5, 116542.59999999999, 218582.19999999992, 262704.0, 0.1644974930582058, 177.94823780518396, 0.018968617168274353], "isController": false}, {"data": ["HomePage-0", 50, 0, 0.0, 361.8199999999999, 219, 677, 249.5, 657.1, 674.0, 677.0, 44.01408450704225, 35.03074108714789, 4.900005501760564], "isController": false}, {"data": ["Cart-1", 50, 0, 0.0, 988.5999999999998, 395, 4430, 441.5, 2700.5, 3107.599999999999, 4430.0, 0.2221985210466439, 0.08354143613570109, 0.02647287067157281], "isController": false}, {"data": ["HomePage-1", 50, 6, 12.0, 106146.35999999999, 62306, 288355, 94826.0, 162984.3, 204909.39999999982, 288355.0, 0.17339677343283996, 171.94499540065058, 0.01758351655592393], "isController": false}, {"data": ["Mens-Clothing-1", 50, 1, 2.0, 718.0400000000001, 0, 16648, 140.0, 869.0, 4172.499999999974, 16648.0, 0.2183482392397988, 0.0933950476435858, 0.027374557571880242], "isController": false}, {"data": ["Mens-Clothing-2", 49, 0, 0.0, 37860.7142857143, 5804, 130176, 35786.0, 50383.0, 58841.5, 130176.0, 0.2029624229571211, 108.33600277028174, 0.02616312483431639], "isController": false}, {"data": ["Womens-traditional-clothing-0", 50, 0, 0.0, 489.69999999999993, 55, 3351, 136.0, 1585.7, 2189.6999999999985, 3351.0, 0.2956131015726617, 0.24307249172283318, 0.0407045384001419], "isController": false}, {"data": ["Womens-traditional-clothing-1", 50, 0, 0.0, 465.4399999999999, 58, 4502, 150.0, 1347.499999999999, 2220.199999999996, 4502.0, 0.2957564859397367, 0.11784047486661382, 0.041879580528575995], "isController": false}, {"data": ["Womens-traditional-clothing-2", 50, 0, 0.0, 25628.46, 1211, 81511, 23978.0, 43997.299999999996, 48495.19999999998, 81511.0, 0.2940380838126154, 153.14324069847277, 0.04192339866859556], "isController": false}, {"data": ["Mens-Clothing-0", 50, 0, 0.0, 375.3600000000001, 120, 2286, 136.5, 854.0, 1176.349999999998, 2286.0, 0.21833489078888763, 0.1765442280988271, 0.02707864368182493], "isController": false}, {"data": ["Cart", 50, 2, 4.0, 93505.31999999999, 61731, 263589, 83901.0, 118235.4, 219428.79999999993, 263589.0, 0.162683629146399, 176.17733697575198, 0.056888431567131394], "isController": false}, {"data": ["Products-1", 50, 0, 0.0, 1006.8399999999998, 385, 6107, 425.0, 2530.4, 3696.7999999999947, 6107.0, 0.2094819929278879, 0.07957860864155117, 0.025776104598548708], "isController": false}, {"data": ["Products-2", 50, 0, 0.0, 31609.940000000002, 12340, 89367, 26130.5, 52624.899999999994, 71405.4, 89367.0, 0.1984111237212403, 79.76605375403766, 0.024607629602146013], "isController": false}, {"data": ["Products-0", 50, 0, 0.0, 1078.16, 387, 9158, 761.5, 2023.6999999999998, 4695.049999999979, 9158.0, 0.2090589420781295, 0.16802295833037167, 0.02490741302102715], "isController": false}, {"data": ["Womens-traditional-clothing", 50, 0, 0.0, 26583.88000000001, 1336, 81780, 24484.5, 46186.0, 49326.249999999985, 81780.0, 0.2923378255912532, 152.61455645956968, 0.12333002017130996], "isController": false}, {"data": ["Skincare Beauty", 50, 2, 4.0, 40939.53999999999, 4224, 131988, 36239.0, 65588.09999999999, 108309.89999999985, 131988.0, 0.2262279653961704, 114.95316303457669, 0.0863024339866797], "isController": false}, {"data": ["Mens-Clothing", 50, 1, 2.0, 38197.159999999996, 787, 131719, 35981.5, 52071.799999999996, 62075.94999999999, 131719.0, 0.20686117133069654, 108.46445934376396, 0.07772242876735565], "isController": false}, {"data": ["Skincare Beauty-0", 50, 0, 0.0, 441.48, 65, 1526, 392.0, 1153.5999999999995, 1286.2499999999998, 1526.0, 0.24679292592757124, 0.20003723488269934, 0.031090124457672546], "isController": false}, {"data": ["Skincare Beauty-1", 50, 0, 0.0, 977.5600000000002, 63, 22649, 407.5, 1385.1, 2390.6499999999937, 22649.0, 0.2453855251986396, 0.0948951835729114, 0.03187136215958893], "isController": false}, {"data": ["mens-shoes-2", 50, 0, 0.0, 26550.460000000006, 1149, 68103, 27302.5, 40909.5, 43013.45, 68103.0, 0.2630208470323358, 126.00169845711972, 0.03313446217497199], "isController": false}, {"data": ["HomePage", 50, 6, 12.0, 106509.68000000001, 62531, 288739, 95177.5, 163386.1, 205330.74999999983, 288739.0, 0.1729906273678092, 171.67993279530364, 0.036801052993948785], "isController": false}, {"data": ["Skincare Beauty-2", 50, 2, 4.0, 39520.280000000006, 2930, 127948, 34629.5, 65013.29999999999, 106885.39999999985, 127948.0, 0.2264974881428565, 114.81893790797861, 0.02845374694794635], "isController": false}, {"data": ["mens-shoes-1", 50, 0, 0.0, 550.38, 58, 7104, 153.0, 868.3, 2116.9499999999935, 7104.0, 0.2635504461909054, 0.10063303169984766, 0.032943805773863175], "isController": false}, {"data": ["mens-shoes-0", 50, 0, 0.0, 677.4, 55, 3231, 400.5, 1761.9999999999995, 2606.0999999999985, 3231.0, 0.2626767814739319, 0.21162924288671275, 0.031808516506608944], "isController": false}, {"data": ["mens-shoes", 50, 0, 0.0, 27778.38, 1265, 68625, 28148.5, 42278.799999999996, 44098.799999999996, 68625.0, 0.2599671401534846, 124.84751302435373, 0.09672605507663831], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 8, 36.36363636363637, 0.5930318754633062], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 926,021; actual size: 347,869)", 2, 9.090909090909092, 0.14825796886582654], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 324,145; actual size: 303,420)", 2, 9.090909090909092, 0.14825796886582654], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 937,270; actual size: 738,504)", 2, 9.090909090909092, 0.14825796886582654], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 340,633; actual size: 291,839)", 2, 9.090909090909092, 0.14825796886582654], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 896,212; actual size: 508,470)", 2, 9.090909090909092, 0.14825796886582654], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.daraz.com.bd:443 failed to respond", 2, 9.090909090909092, 0.14825796886582654], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 985,919; actual size: 787,183)", 2, 9.090909090909092, 0.14825796886582654], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1349, 22, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 8, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 926,021; actual size: 347,869)", 2, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 324,145; actual size: 303,420)", 2, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 937,270; actual size: 738,504)", 2, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 340,633; actual size: 291,839)", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Cart-2", 50, 2, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 926,021; actual size: 347,869)", 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["HomePage-1", 50, 6, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 3, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 937,270; actual size: 738,504)", 1, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 896,212; actual size: 508,470)", 1, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 985,919; actual size: 787,183)", 1, "", ""], "isController": false}, {"data": ["Mens-Clothing-1", 50, 1, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.daraz.com.bd:443 failed to respond", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Cart", 50, 2, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 926,021; actual size: 347,869)", 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Skincare Beauty", 50, 2, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 324,145; actual size: 303,420)", 1, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 340,633; actual size: 291,839)", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Mens-Clothing", 50, 1, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.daraz.com.bd:443 failed to respond", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["HomePage", 50, 6, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 3, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 937,270; actual size: 738,504)", 1, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 896,212; actual size: 508,470)", 1, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 985,919; actual size: 787,183)", 1, "", ""], "isController": false}, {"data": ["Skincare Beauty-2", 50, 2, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 324,145; actual size: 303,420)", 1, "Non HTTP response code: org.apache.http.TruncatedChunkException/Non HTTP response message: Truncated chunk (expected size: 340,633; actual size: 291,839)", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
